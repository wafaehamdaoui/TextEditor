#include "textediter.h"
#include "ui_textediter.h"
#include <QtWidgets>

TextEditer::TextEditer(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TextEditer)
{
    ui->setupUi(this);
}

TextEditer::~TextEditer()
{
    delete ui;
}

