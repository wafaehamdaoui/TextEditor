#ifndef TEXTEDITER_H
#define TEXTEDITER_H

#include <QMainWindow>
#include <QPlainTextEdit>
#include <QSessionManager>

QT_BEGIN_NAMESPACE
namespace Ui { class TextEditer; }
QT_END_NAMESPACE

class TextEditer : public QMainWindow
{
    Q_OBJECT

public:
    TextEditer(QWidget *parent = nullptr);
    ~TextEditer();

        void loadFile(const QString &fileName);

protected:
        void closeEvent(QCloseEvent *event) override;

private slots:
        void newFile();
        void open();
        bool save();
        bool saveAs();
        void about();
        void documentWasModified();

        void commitData(QSessionManager &);


private:
        void createActions();
        void createStatusBar();
        void readSettings();
        void writeSettings();
        bool maybeSave();
        bool saveFile(const QString &fileName);
        void setCurrentFile(const QString &fileName);
        QString strippedName(const QString &fullFileName);

        QPlainTextEdit *textEdit;
        QString curFile;

private:
    Ui::TextEditer *ui;
};
#endif // TEXTEDITER_H
