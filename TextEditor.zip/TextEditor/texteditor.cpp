
#include "texteditor.h"
#include "ui_texteditor.h"
#include <QFileDialog>
#include <QFile>
#include <QMessageBox>
#include <QPrinter>
#include <QPrintDialog>
#include <QColor>
#include <sstream>

using std::istringstream;

TextEditor::TextEditor(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TextEditor)
{
    ui->setupUi(this);
    setCentralWidget(ui->textEdit);
}

TextEditor::~TextEditor()
{
    delete ui;
}


void TextEditor::on_actionNew_triggered()
{
    currentFile.clear();
    ui->textEdit->setText(QString());
}


void TextEditor::on_actionOpen_triggered()
{
    QString filename = QFileDialog::getOpenFileName(this,"open the file");
    QFile file(filename);
    currentFile = filename;
    // Try to open the file as a read only file if possible or display a
        // warning dialog box
        if (!file.open(QIODevice::ReadOnly | QFile::Text)) {
            QMessageBox::warning(this, "Warning", "Cannot open file: " + file.errorString());
            return;
        }

        // Set the title for the window to the file name
        setWindowTitle(filename);

        // Interface for reading text
        QDataStream in(&file);

        //  Copy text in the string
//        QString text = in.();

//        // Put the text in the textEdit widget
//        ui->textEdit->setText(text);

        // Close the file
        file.close();

}


void TextEditor::on_actionSave_triggered()
{
    QString fileName = QFileDialog::getSaveFileName(this, "Save");
        QFile file(fileName);
        if (!file.open(QFile::WriteOnly | QFile::Text)) {
            QMessageBox::warning(this, "Warning", "Cannot save file: " + file.errorString());
            return;
        }
        currentFile = fileName;
        setWindowTitle(fileName);
        QDataStream out(&file);
        QString text = ui->textEdit->toPlainText();
        out << text;
        file.close();

}



void TextEditor::on_actionSave_as_triggered()
{
    // Opens a dialog for saving a file
        QString fileName = QFileDialog::getSaveFileName(this, "Save as");

        // An object for reading and writing files
        QFile file(fileName);

        // Try to open a file with write only options
        if (!file.open(QFile::WriteOnly | QFile::Text)) {
            QMessageBox::warning(this, "Warning", "Cannot save file: " + file.errorString());
            return;
        }

        // Store the currentFile name
        currentFile = fileName;

        // Set the title for the window to the file name
        setWindowTitle(fileName);

        // Interface for writing text
        QDataStream out(&file);

        // Copy text in the textEdit widget and convert to plain text
        QString text = ui->textEdit->toPlainText();

        // Output to file
        out << text;

        // Close the file
        file.close();
}


void TextEditor::on_actionExit_triggered()
{
    QApplication::quit();
}


void TextEditor::on_actionCut_triggered()
{
    ui->textEdit->cut();
}


void TextEditor::on_actionCopy_triggered()
{
    ui->textEdit->copy();
}


void TextEditor::on_actionPaste_triggered()
{
    ui->textEdit->paste();
}


void TextEditor::on_actionAbout_triggered()
{
    QMessageBox::about(this, "about me","I'm trying to create a TextEditor applicaton ");
}


void TextEditor::on_actionSelect_All_triggered()
{
  ui->textEdit->selectAll();
}


void TextEditor::on_actionZoom_in_triggered()
{
    ui->textEdit->zoomIn();
}


void TextEditor::on_actionZoom_out_triggered()
{
    ui->textEdit->zoomOut();
}


void TextEditor::on_actionItalic_triggered()
{
    ui->textEdit->setFontItalic(true);
}


void TextEditor::on_actionunderline_triggered()
{
    ui->textEdit->setFontUnderline(true);
}




void TextEditor::on_actionRed_triggered()
{
    ui->textEdit->setTextColor(QColor(255,0,0));
}


void TextEditor::on_actionblue_triggered()
{
    ui->textEdit->setTextColor(QColor(0,0,255));
}


void TextEditor::on_actionyello_triggered()
{
    ui->textEdit->setTextColor(QColor(255,255,0));
}

